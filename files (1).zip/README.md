# House Price Analytics

**Author:** Rashmi

A data analytics project exploring 300 residential home sales, identifying
what drives sale price, and building a regression model to predict it.

## Files

| File | Description |
|---|---|
| `Rashmi_housepriceanalytics.ipynb` | Jupyter notebook — full analysis, charts, model training/comparison, and a live prediction demo |
| `requirements.txt` | Python packages needed to run the notebook |
| `Rashmi_projectreport.docx` | Written project report (executive summary, findings, model results, conclusions) |
| `README.md` | This file |
| `house_prices_practice.csv` | Source dataset (300 rows, 10 columns) — place alongside the notebook before running it |

## Setup

```bash
pip install -r requirements.txt
jupyter notebook Rashmi_housepriceanalytics.ipynb
```

Make sure `house_prices_practice.csv` is in the same folder as the notebook
(the notebook loads it with a relative path: `pd.read_csv("house_prices_practice.csv")`).

## What's in the notebook

1. Setup & imports
2. Load the dataset
3. Dataset overview (shape, dtypes, missing values, descriptive statistics)
4. Correlation of each feature with `SalePrice`, plus a correlation heatmap
5. Distribution of sale price and its relationship with living area
6. Train/test split (80/20)
7. Model 1 — Linear Regression (trained and evaluated)
8. Model 2 — Random Forest (trained and evaluated, for comparison)
9. Feature importance
10. A reusable `predict_price()` function with a worked example
11. Conclusions

## Dataset

10 columns, no missing values:

| Column | Description |
|---|---|
| `Id` | Row identifier |
| `OverallQual` | Overall material/finish quality, 1 (worst) – 10 (best) |
| `GrLivArea` | Above-grade living area (sq ft) |
| `GarageCars` | Garage capacity, in cars |
| `TotalBsmtSF` | Total basement area (sq ft) |
| `YearBuilt` | Original construction year |
| `FullBath` | Full bathrooms above grade |
| `BedroomAbvGr` | Bedrooms above grade |
| `LotArea` | Lot size (sq ft) |
| `SalePrice` | Sale price in USD — the prediction target |

## Key results

- **Living area (`GrLivArea`)** is the strongest driver of sale price (correlation r = 0.745).
- **Overall quality** and **garage capacity** are secondary but meaningful contributors.
- **Linear Regression** outperformed Random Forest on this dataset — R² = 0.972, MAE ≈ $10,432 — and is the recommended model.

Full details, tables, and charts are in `Rashmi_projectreport.docx`.

## Requirements

- Python 3.9+
- Jupyter (installed via `requirements.txt`)
